package lvlUp8;

public interface IntList {

    // public static final int INT = 10;

    void add(int value);

    void removeFirst();

    void display();
    int get(int index);
    void addFirst(int value);
    void removeLast();

}
