package lvlUp7.fifth;

public class MyClass {
    private boolean aBoolean;

    public boolean isaBoolean() {
        return aBoolean;
    }

    public MyClass(boolean aBoolean) {
        this.aBoolean = aBoolean;
    }
}
