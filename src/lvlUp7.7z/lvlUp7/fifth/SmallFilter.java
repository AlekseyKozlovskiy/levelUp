package lvlUp7.fifth;

public class SmallFilter extends BaseFilter {
    @Override
    boolean filter(Object object) {
        return true;
    }
}
