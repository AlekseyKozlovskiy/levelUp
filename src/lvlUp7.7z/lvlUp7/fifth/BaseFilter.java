package lvlUp7.fifth;

public class BaseFilter {
    boolean filter(Object object){
        return false;
    }
}
