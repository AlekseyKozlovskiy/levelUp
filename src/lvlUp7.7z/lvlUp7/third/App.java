package lvlUp7.third;

import java.util.Random;

public class App {
    public static void main(String[] args) {
        int[] mass = Mass.fillMass();
        for (int i : mass) {
            System.out.println(i);
        }

    }
}
