package lvlUp6.second;

public class Calculator {
    public double sum(double a, double b) {
        return a + b;
    }

    public int sum(int a, int b) {
        return a + b;
    }

    public long sum(long a, long b) {
        return a + b;
    }


    public double division(double a, double b) {
        return a / b;
    }

    public int division(int a, int b) {
        return a / b;
    }

    public long division(long a, long b) {
        return a / b;
    }


    public double multiplication(double a, double b) {
        return a * b;
    }

    public int multiplication(int a, int b) {
        return a * b;
    }

    public long multiplication(long a, long b) {
        return a * b;
    }


    public double subtraction(double a, double b) {
        return a - b;
    }

    public int subtraction(int a, int b) {
        return a - b;
    }

    public long subtraction(long a, long b) {
        return a - b;
    }
}
