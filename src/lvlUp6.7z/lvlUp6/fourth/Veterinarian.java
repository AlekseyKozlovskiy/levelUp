package lvlUp6.fourth;

public class Veterinarian {

    public void treatAnimal(Animal animal) {
        System.out.print(animal.getFood() + "\t");
        System.out.println(animal.getLocation());
    }
}
